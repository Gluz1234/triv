#include "IRequestHandler.h"

IRequestHandler::IRequestHandler()
{
}

IRequestHandler::~IRequestHandler()
{
}
